/* Copyright (C) 2004 - 2006  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.nativequery.expr.cmp;

public class MethodCallValue extends ComparisonOperandDescendant {
	private String _methodName;
	private Class[] _paramTypes; 
	private ComparisonOperand[] _args;
	
	public MethodCallValue(ComparisonOperandAnchor parent, String name, Class[] paramTypes, ComparisonOperand[] args) {
		super(parent);
		_methodName = name;
		_paramTypes = paramTypes;
		_args = args;
	}

	public void accept(ComparisonOperandVisitor visitor) {
		visitor.visit(this);
	}

	public String methodName() {
		return _methodName;
	}

	public Class[] paramTypes() {
		return _paramTypes;
	}

	public ComparisonOperand[] args() {
		return _args;
	}
	
	public boolean equals(Object obj) {
		if(!super.equals(obj)) {
			return false;
		}
		MethodCallValue casted=(MethodCallValue)obj;
		return _methodName.equals(casted._methodName)&&arrayCmp(_paramTypes, casted._paramTypes)&&arrayCmp(_args, casted._args);
	}

	public int hashCode() {
		int hc=super.hashCode();
		hc*=29+_methodName.hashCode();
		hc*=29+_paramTypes.hashCode();
		hc*=29+_args.hashCode();
		return hc;
	}
	
	public String toString() {
		String str=super.toString()+"."+_methodName+"(";
		for (int paramIdx = 0; paramIdx < _paramTypes.length; paramIdx++) {
			if(paramIdx>0) {
				str+=",";
			}
			str+=_paramTypes[paramIdx]+":"+_args[paramIdx];
		}
		str+=")";
		return str;
	}
	
	private boolean arrayCmp(Object[] a,Object[] b) {
		if(a.length!=b.length) {
			return false;
		}
		for (int paramIdx = 0; paramIdx < a.length; paramIdx++) {
			if(!a[paramIdx].equals(b[paramIdx])) {
				return false;
			}
		}
		return true;
	}
}
