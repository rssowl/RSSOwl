/* Copyright (C) 2004 - 2006  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.internal.btree;

import com.db4o.foundation.*;
import com.db4o.internal.*;
import com.db4o.internal.handlers.*;
import com.db4o.internal.ix.*;


/**
 * @exclude
 */
public class FieldIndexKeyHandler implements Indexable4{
	
    private final Indexable4 _valueHandler;
    
    private final IntHandler _parentIdHandler;
    
    public FieldIndexKeyHandler(ObjectContainerBase stream, Indexable4 delegate_) {
        _parentIdHandler = new IDHandler(stream);
        _valueHandler = delegate_;
    }

    public Object comparableObject(Transaction trans, Object indexEntry) {
        throw new NotImplementedException();
    }

    public int linkLength() {
        return _valueHandler.linkLength() + Const4.INT_LENGTH;
    }

    public Object readIndexEntry(Buffer a_reader) {
        // TODO: could read int directly here with a_reader.readInt()
        int parentID = readParentID(a_reader);
        Object objPart = _valueHandler.readIndexEntry(a_reader);
        if (parentID < 0){
            objPart = null;
            parentID = - parentID;
        }
        return new FieldIndexKey(parentID, objPart);
    }

	private int readParentID(Buffer a_reader) {
		return ((Integer)_parentIdHandler.readIndexEntry(a_reader)).intValue();
	}

    public void writeIndexEntry(Buffer writer, Object obj) {
        FieldIndexKey composite = (FieldIndexKey)obj;
        int parentID = composite.parentID();
        Object value = composite.value();
        if (value == null){
            parentID = - parentID;
        }
        _parentIdHandler.write(parentID, writer);
        _valueHandler.writeIndexEntry(writer, composite.value());
    }
    
    public Indexable4 valueHandler() {
    	return _valueHandler;
    }
    
    public Comparable4 prepareComparison(Object obj) {
        FieldIndexKey composite = (FieldIndexKey)obj;
        _valueHandler.prepareComparison(composite.value());
        _parentIdHandler.prepareComparison(composite.parentID());
        return this;
    }

    public int compareTo(Object obj) {
    	if (null == obj) {
    		throw new ArgumentNullException();
    	}
        FieldIndexKey composite = (FieldIndexKey)obj;
        int delegateResult = _valueHandler.compareTo(composite.value());  
        if(delegateResult != 0 ){
            return delegateResult;
        }
        return _parentIdHandler.compareTo(composite.parentID());
    }

    public boolean isEqual(Object obj) {
    	throw new NotImplementedException();
    }

    public boolean isGreater(Object obj) {
    	throw new NotImplementedException();
    }

    public boolean isSmaller(Object obj) {
    	throw new NotImplementedException();
    }

    public Object current() {
        return new FieldIndexKey(_parentIdHandler.currentInt(), _valueHandler.current());  
    }

	public void defragIndexEntry(ReaderPair readers) {
		_parentIdHandler.defragIndexEntry(readers);
        _valueHandler.defragIndexEntry(readers);
	}
}

