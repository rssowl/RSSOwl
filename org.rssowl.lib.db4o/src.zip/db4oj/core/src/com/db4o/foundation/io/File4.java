/* Copyright (C) 2004 - 2006  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.foundation.io;

import java.io.*;

/**
 * @sharpen.ignore
 */
public class File4 {

	public static void rename(String oldPath,String newPath) throws IOException {
		if(!new java.io.File(oldPath).renameTo(new File(newPath))) {
			throw new IOException("Could not rename '"+oldPath+"' to '"+newPath+"'.");
		}
	}
	
    public static void copy(String source, String target) {
        try {
        	java.io.File sourceFile = new java.io.File(source);
        	
            java.io.File targetFile = new java.io.File(target);
			targetFile.mkdirs();
            targetFile.delete();
            
            if (sourceFile.isDirectory()) {
                copyDirectory(sourceFile, targetFile);
            } else {
                copyFile(sourceFile, targetFile);
            }
        } catch (Exception e) {
            System.out.println("File.copy failed.");
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

	public static void copyFile(File source, File target) throws IOException {
		final int bufferSize = 64000;

		RandomAccessFile rafIn = new RandomAccessFile(source.getAbsolutePath(), "r");
		RandomAccessFile rafOut = new RandomAccessFile(target.getAbsolutePath(), "rw");
		final long len = rafIn.length();
		final byte[] bytes = new byte[bufferSize];

		long totalRead=0;
		while (totalRead<len) {
		    int numRead=rafIn.read(bytes,0,bufferSize);
		    rafOut.write(bytes,0,numRead);
		    totalRead+=numRead;
		}

		rafIn.close();
		rafOut.close();
	}

	private static void copyDirectory(File source, File target) {
		String[] files = source.list();
		if (files != null) {
		    for (int i = 0; i < files.length; i++) {
		        copy(Path4.combine(source.getAbsolutePath(), files[i]),
		        	Path4.combine(target.getAbsolutePath(), files[i]));
		    }
		}
	}
	
    public static void delete(String fname) {
		new File(fname).delete();
	}
    
    public static boolean exists(String fname){
        return new File(fname).exists();
    }

	public static void mkdirs(String path) {
		new File(path).mkdirs();
	}
}
